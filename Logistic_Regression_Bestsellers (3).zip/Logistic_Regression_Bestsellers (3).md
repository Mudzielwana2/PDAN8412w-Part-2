```python
import numpy as np
import pandas as pd
import matplotlib
%matplotlib inline
import matplotlib.pyplot as plt
import seaborn as sns
import statsmodels.api as sm
from statsmodels.stats.outliers_influence import variance_inflation_factor

sns.set_theme(style="whitegrid")
np.random.seed(42)
OUT = "figs/"
import os; os.makedirs(OUT, exist_ok=True)
```

Load data


```python
df = pd.read_csv("books.csv")
print("Shape:", df.shape)
print(df.dtypes)
```

    Shape: (10000, 23)
    book_id                        int64
    goodreads_book_id              int64
    best_book_id                   int64
    work_id                        int64
    books_count                    int64
    isbn                             str
    isbn13                       float64
    authors                          str
    original_publication_year    float64
    original_title                   str
    title                            str
    language_code                    str
    average_rating               float64
    ratings_count                  int64
    work_ratings_count             int64
    work_text_reviews_count        int64
    ratings_1                      int64
    ratings_2                      int64
    ratings_3                      int64
    ratings_4                      int64
    ratings_5                      int64
    image_url                        str
    small_image_url                  str
    dtype: object
    

DATA CLEANING


```python
# 2a. Missing values
print("Missing values per column:\n", df.isna().sum()[df.isna().sum() > 0])
# 2b. Remove duplicate titles (same book listed twice) keeping the most-rated copy
before = len(df)
df = df.sort_values("ratings_count", ascending=False).drop_duplicates("title").reset_index(drop=True)
print("Duplicates removed:", before - len(df))
# 2c. Missing publication year -> median (only ~0.2% missing)
df["original_publication_year"] = df["original_publication_year"].fillna(df["original_publication_year"].median())
# 2d. Language: group all English variants together, everything else = 'other'
df["language_code"] = df["language_code"].fillna("unknown")
df["is_english"] = df["language_code"].str.lower().str.startswith("en").astype(int)
```

    Missing values per column:
     isbn                          700
    isbn13                        585
    original_publication_year      21
    original_title                585
    language_code                1084
    dtype: int64
    Duplicates removed: 36
    

TARGET ENGINEERING


```python
# No explicit 'bestseller' column exists, so we define one from popularity.
threshold = df["ratings_count"].quantile(0.80)
df["bestseller"] = (df["ratings_count"] >= threshold).astype(int)
print(f"Bestseller threshold (ratings_count >= {threshold:,.0f}); class balance:\n",
      df["bestseller"].value_counts(normalize=True))
```

    Bestseller threshold (ratings_count >= 50,191); class balance:
     bestseller
    0    0.79998
    1    0.20002
    Name: proportion, dtype: float64
    

FEATURE ENGINEERING


```python
# NOTE: ratings_count, work_ratings_count, work_text_reviews_count and ratings_1..5 are EXCLUDED
# because they define / leak the target (data leakage).
df["is_series"] = df["title"].str.contains(r"#\d", regex=True).astype(int)
df["n_authors"] = df["authors"].str.count(",") + 1
df["title_length"] = df["title"].str.len()
df["author_book_count"] = df.groupby("authors")["book_id"].transform("count")
df["book_age"] = 2017 - df["original_publication_year"]
df["log_books_count"] = np.log1p(df["books_count"])   # heavily right-skewed -> log

candidates = ["average_rating", "book_age", "log_books_count", "is_english",
              "is_series", "n_authors", "title_length", "author_book_count"]
```

EDA


```python
fig, ax = plt.subplots(1, 2, figsize=(12, 4))
sns.histplot(df["ratings_count"], bins=60, ax=ax[0], color="#4C72B0")
ax[0].set_title("ratings_count (raw) - heavily right-skewed"); ax[0].set_xlim(0, 400000)
sns.histplot(np.log10(df["ratings_count"]), bins=50, ax=ax[1], color="#55A868")
ax[1].axvline(np.log10(threshold), color="red", ls="--", label="Bestseller cut-off")
ax[1].set_title("log10(ratings_count) with bestseller threshold"); ax[1].legend()
plt.tight_layout(); plt.savefig(OUT + "01_target_distribution.png", dpi=130); plt.show()

fig, ax = plt.subplots(1, 3, figsize=(15, 4))
df["bestseller"].map({0: "Not bestseller", 1: "Bestseller"}).value_counts().plot.bar(ax=ax[0], color=["#4C72B0", "#C44E52"])
ax[0].set_title("Class balance (80/20)"); ax[0].tick_params(axis="x", rotation=0)
sns.boxplot(data=df, x="bestseller", y="average_rating", ax=ax[1], hue="bestseller", legend=False, palette=["#4C72B0", "#C44E52"])
ax[1].set_title("Average rating by class")
sns.boxplot(data=df, x="bestseller", y="log_books_count", ax=ax[2], hue="bestseller", legend=False, palette=["#4C72B0", "#C44E52"])
ax[2].set_title("log(editions) by class")
plt.tight_layout(); plt.savefig(OUT + "02_class_vs_features.png", dpi=130); plt.show()

plt.figure(figsize=(9, 7))
sns.heatmap(df[candidates + ["bestseller"]].corr(), annot=True, fmt=".2f", cmap="coolwarm", center=0)
plt.title("Correlation matrix"); plt.tight_layout(); plt.savefig(OUT + "03_correlation.png", dpi=130); plt.show()

df[candidates].hist(bins=30, figsize=(13, 8), color="#4C72B0")
plt.suptitle("Feature distributions (before scaling)"); plt.tight_layout()
plt.savefig(OUT + "04_feature_hists.png", dpi=130); plt.show()

# Outliers: IQR count for each numeric feature
for c in ["average_rating", "book_age", "log_books_count", "title_length", "author_book_count"]:
    q1, q3 = df[c].quantile([.25, .75]); iqr = q3 - q1
    n = ((df[c] < q1 - 1.5 * iqr) | (df[c] > q3 + 1.5 * iqr)).sum()
    print(f"{c}: {n} IQR outliers (kept - genuine values, scaling handles range)")
```


    
![png](output_10_0.png)
    



    
![png](output_10_1.png)
    



    
![png](output_10_2.png)
    



    
![png](output_10_3.png)
    


    average_rating: 158 IQR outliers (kept - genuine values, scaling handles range)
    book_age: 1025 IQR outliers (kept - genuine values, scaling handles range)
    log_books_count: 527 IQR outliers (kept - genuine values, scaling handles range)
    title_length: 303 IQR outliers (kept - genuine values, scaling handles range)
    author_book_count: 711 IQR outliers (kept - genuine values, scaling handles range)
    

6. FEATURE SELECTION 


```python
def backward_elimination(X, y, alpha=0.05):
    feats = list(X.columns)
    while True:
        m = sm.Logit(y, sm.add_constant(X[feats])).fit(disp=0)
        pvals = m.pvalues.drop("const")
        worst = pvals.idxmax()
        if pvals[worst] > alpha:
            print(f"Dropping {worst} (p={pvals[worst]:.3f})"); feats.remove(worst)
        else:
            return feats, m

# Multicollinearity check first (VIF > 5 is a concern)
Xv = sm.add_constant(df[candidates])
vif = pd.Series([variance_inflation_factor(Xv.values, i) for i in range(1, Xv.shape[1])], index=candidates)
print("VIF:\n", vif.round(2))

selected, sel_model = backward_elimination(df[candidates], df["bestseller"])
print("Selected features:", selected)
print(sel_model.summary().tables[1])
```

    VIF:
     average_rating       1.11
    book_age             1.11
    log_books_count      1.16
    is_english           1.03
    is_series            1.27
    n_authors            1.06
    title_length         1.16
    author_book_count    1.14
    dtype: float64
    Dropping title_length (p=0.729)
    Dropping is_series (p=0.482)
    Selected features: ['average_rating', 'book_age', 'log_books_count', 'is_english', 'n_authors', 'author_book_count']
    =====================================================================================
                            coef    std err          z      P>|z|      [0.025      0.975]
    -------------------------------------------------------------------------------------
    const               -12.5898      0.554    -22.719      0.000     -13.676     -11.504
    average_rating        1.3189      0.121     10.883      0.000       1.081       1.556
    book_age             -0.0023      0.000     -5.429      0.000      -0.003      -0.001
    log_books_count       1.2673      0.040     31.828      0.000       1.189       1.345
    is_english            1.1879      0.118     10.042      0.000       0.956       1.420
    n_authors            -0.1500      0.046     -3.233      0.001      -0.241      -0.059
    author_book_count     0.0080      0.002      3.274      0.001       0.003       0.013
    =====================================================================================
    

TRAIN / TEST SPLIT (stratified, implemented by hand) + STANDARDISATION


```python
def stratified_split(y, test_size=0.2, seed=42):
    rng = np.random.default_rng(seed)
    test_idx = []
    for cls in np.unique(y):
        idx = np.where(y == cls)[0]; rng.shuffle(idx)
        test_idx += list(idx[: int(len(idx) * test_size)])
    test_idx = np.array(test_idx); train_idx = np.setdiff1d(np.arange(len(y)), test_idx)
    return train_idx, test_idx

X_all = df[selected].values.astype(float); y_all = df["bestseller"].values
tr, te = stratified_split(y_all)
mu, sd = X_all[tr].mean(0), X_all[tr].std(0)       # fit scaler on TRAIN only (no leakage)
X_train, X_test = (X_all[tr] - mu) / sd, (X_all[te] - mu) / sd
y_train, y_test = y_all[tr], y_all[te]
print("Train:", X_train.shape, "Test:", X_test.shape)
```

    Train: (7972, 6) Test: (1992, 6)
    

LOGISTIC REGRESSION FROM SCRATCH


```python
class LogisticRegressionScratch:
    """Binary logistic regression via batch gradient descent with optional L2 penalty
    and optional class weighting."""
    def __init__(self, lr=0.1, n_iter=2000, l2=0.0, class_weight=None):
        self.lr, self.n_iter, self.l2, self.class_weight = lr, n_iter, l2, class_weight
        self.loss_history = []

    @staticmethod
    def _sigmoid(z):
        return 1.0 / (1.0 + np.exp(-np.clip(z, -500, 500)))   # clip avoids overflow

    def fit(self, X, y):
        n, d = X.shape
        self.w, self.b = np.zeros(d), 0.0
        # sample weights: 'balanced' up-weights the minority class
        if self.class_weight == "balanced":
            sw = np.where(y == 1, n / (2 * y.sum()), n / (2 * (n - y.sum())))
        else:
            sw = np.ones(n)
        for _ in range(self.n_iter):
            p = self._sigmoid(X @ self.w + self.b)               # predicted probabilities
            eps = 1e-12
            loss = -np.mean(sw * (y * np.log(p + eps) + (1 - y) * np.log(1 - p + eps))) \
                   + 0.5 * self.l2 * np.sum(self.w ** 2) / n
            self.loss_history.append(loss)
            err = (p - y) * sw                                    # dL/dz
            self.w -= self.lr * (X.T @ err / n + self.l2 * self.w / n)   # gradient step on weights
            self.b -= self.lr * err.mean()                        # gradient step on bias
        return self

    def predict_proba(self, X): return self._sigmoid(X @ self.w + self.b)
    def predict(self, X, thr=0.5): return (self.predict_proba(X) >= thr).astype(int)
```

METRICS FROM SCRATCH


```python
def confusion(y, yhat):
    tp = int(((y == 1) & (yhat == 1)).sum()); tn = int(((y == 0) & (yhat == 0)).sum())
    fp = int(((y == 0) & (yhat == 1)).sum()); fn = int(((y == 1) & (yhat == 0)).sum())
    return tp, tn, fp, fn

def metrics(y, yhat):
    tp, tn, fp, fn = confusion(y, yhat)
    acc = (tp + tn) / len(y)
    prec = tp / (tp + fp) if tp + fp else 0.0
    rec = tp / (tp + fn) if tp + fn else 0.0
    f1 = 2 * prec * rec / (prec + rec) if prec + rec else 0.0
    return dict(accuracy=acc, precision=prec, recall=rec, f1=f1)

def roc_curve(y, p):
    order = np.argsort(-p); y_s = y[order]
    tpr = np.cumsum(y_s) / y.sum(); fpr = np.cumsum(1 - y_s) / (len(y) - y.sum())
    return np.r_[0, fpr], np.r_[0, tpr]

def auc(fpr, tpr): return np.trapezoid(tpr, fpr)
```

MODEL 1 - default hyperparameters


```python
m1 = LogisticRegressionScratch(lr=0.1, n_iter=2000).fit(X_train, y_train)
res1 = metrics(y_test, m1.predict(X_test)); f1_, t1_ = roc_curve(y_test, m1.predict_proba(X_test)); res1["auc"] = auc(f1_, t1_)
print("Model 1 (default):", {k: round(v, 3) for k, v in res1.items()})
```

    Model 1 (default): {'accuracy': 0.821, 'precision': 0.672, 'recall': 0.206, 'f1': 0.315, 'auc': np.float64(0.799)}
    

11. MODEL 2 - retrain


```python
m2 = LogisticRegressionScratch(lr=0.1, n_iter=2000, l2=1.0, class_weight="balanced").fit(X_train, y_train)
res2 = metrics(y_test, m2.predict(X_test)); f2_, t2_ = roc_curve(y_test, m2.predict_proba(X_test)); res2["auc"] = auc(f2_, t2_)
print("Model 2 (balanced + L2):", {k: round(v, 3) for k, v in res2.items()})

# Learning-rate comparison to justify lr choice
plt.figure(figsize=(7, 4))
for lr in [0.01, 0.1, 0.5]:
    mm = LogisticRegressionScratch(lr=lr, n_iter=500).fit(X_train, y_train)
    plt.plot(mm.loss_history, label=f"lr={lr}")
plt.xlabel("Iteration"); plt.ylabel("Log-loss"); plt.title("Convergence vs learning rate"); plt.legend()
plt.tight_layout(); plt.savefig(OUT + "05_learning_rate.png", dpi=130); plt.show()
```

    Model 2 (balanced + L2): {'accuracy': 0.721, 'precision': 0.396, 'recall': 0.754, 'f1': 0.519, 'auc': np.float64(0.798)}
    


    
![png](output_22_1.png)
    


EVALUATION VISUALS


```python
fig, ax = plt.subplots(1, 3, figsize=(17, 4.5))
for a, (name, mod) in zip(ax[:2], [("Model 1 (default)", m1), ("Model 2 (balanced + L2)", m2)]):
    tp, tn, fp, fn = confusion(y_test, mod.predict(X_test))
    sns.heatmap([[tn, fp], [fn, tp]], annot=True, fmt="d", cmap="Blues", cbar=False, ax=a,
                xticklabels=["Pred 0", "Pred 1"], yticklabels=["Actual 0", "Actual 1"])
    a.set_title(name)
ax[2].plot(f1_, t1_, label=f"Model 1 (AUC={res1['auc']:.3f})")
ax[2].plot(f2_, t2_, label=f"Model 2 (AUC={res2['auc']:.3f})")
ax[2].plot([0, 1], [0, 1], "k--", label="Random"); ax[2].set_xlabel("FPR"); ax[2].set_ylabel("TPR")
ax[2].set_title("ROC curve"); ax[2].legend()
plt.tight_layout(); plt.savefig(OUT + "06_evaluation.png", dpi=130); plt.show()

comp = pd.DataFrame({"Model 1 (default)": res1, "Model 2 (balanced + L2)": res2}).T.round(3)
print(comp)
comp.plot.bar(figsize=(9, 4), rot=0, colormap="viridis"); plt.title("Metric comparison"); plt.ylim(0, 1)
plt.tight_layout(); plt.savefig(OUT + "07_metric_comparison.png", dpi=130); plt.show()

# Coefficients = interpretation (odds ratios)
coef = pd.DataFrame({"feature": selected, "coef": m2.w, "odds_ratio": np.exp(m2.w)}).sort_values("coef")
print(coef.round(3))
plt.figure(figsize=(7, 4)); plt.barh(coef["feature"], coef["coef"], color=np.where(coef["coef"] > 0, "#55A868", "#C44E52"))
plt.title("Standardised coefficients (Model 2)"); plt.axvline(0, color="k", lw=.8)
plt.tight_layout(); plt.savefig(OUT + "08_coefficients.png", dpi=130); plt.show()
```


    
![png](output_24_0.png)
    


                             accuracy  precision  recall     f1    auc
    Model 1 (default)           0.821      0.672   0.206  0.315  0.799
    Model 2 (balanced + L2)     0.721      0.396   0.754  0.519  0.798
    


    
![png](output_24_2.png)
    


                 feature   coef  odds_ratio
    1           book_age -0.223       0.800
    4          n_authors -0.099       0.906
    5  author_book_count  0.115       1.122
    0     average_rating  0.312       1.366
    3         is_english  0.367       1.443
    2    log_books_count  1.176       3.243
    


    
![png](output_24_4.png)
    


SANITY CHECK vs scikit-learn (validates the scratch implementation)


```python
from sklearn.linear_model import LogisticRegression
sk = LogisticRegression(C=1e6, max_iter=5000).fit(X_train, y_train)
print("Scratch vs sklearn coefficient max abs diff:", np.abs(sk.coef_[0] - m1.w).max().round(4))
print("Test accuracy - scratch:", round(res1["accuracy"], 4), "sklearn:", round(sk.score(X_test, y_test), 4))
```

    Scratch vs sklearn coefficient max abs diff: 0.0085
    Test accuracy - scratch: 0.8213 sklearn: 0.8213
    
